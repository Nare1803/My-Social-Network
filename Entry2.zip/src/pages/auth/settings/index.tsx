export const Settings = () => {
    return <>
        <h1>Settings</h1>
    </>
}